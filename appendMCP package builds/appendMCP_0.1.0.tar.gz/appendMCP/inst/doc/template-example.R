## ----setup, include=FALSE-------------------------------
library(appendMCP)
library(dplyr)
library(flextable)
library(forcats)
library(ggplot2)
library(gMCPLite)
library(gsDesign)
library(kableExtra)
library(knitr)
library(lubridate)
library(magrittr)
library(purrr)
library(RColorBrewer)
library(rlang)
library(stats)
library(tibble)
library(tidyr)
library(vistime)


knitr::opts_chunk$set(
  collapse   = TRUE,
  comment    = "#>",
  fig.width  = 6.5,
  fig.height = 4.5,
  message    = FALSE,
  warning    = FALSE
)
options(width = 58)

## ----input, fig.height=5, fig.width=5, fig.align="center"----
######### << START INPUT >> ####################################################

##### 1. Global parameters
# Number of hypotheses included in the testing strategy with FWER control
numHyp        <- 4
# Allowed one-sided FWER
alphaTotal    <- 0.025
# Number of digits to report for p-value boundaries
pdigits       <- 5
# Number of rounding digits for information fractions
idigits       <- 2
# Data availability at IA in percent relative to max
plotInPercent <- FALSE
# Time limit in plot
Tmax_atPlot   <- 60
# Study specific parameter for multiple testing procedure
mtParam       <- 0.4

##### 2. Enrollment
# (This is aux to define enrollment per hypothesis below, might need enrollment
# per hypothesis for sub-population analysis)
enrollmentAll <- tibble::tibble(stratum  = "All",
                                duration = 250*2/25,
                                rate     = 25)

##### 3. Main input tibble
# One row per hypothesis
inputD        <- tibble::tibble(
  # Hypothesis IDs
  id            = paste0("H", 1:numHyp),
  # Hypothesis tags, used in graph and output tables
  tag           = c("PFS B+", "PFS", "ORR", "PRO"),
  # The fields 'regimen', 'ep', and 'suffix' are pasted together into 'descr'
  # field for the table defining hypotheses, 'tblInput'
  regimen       = rep("DrugX" , each = numHyp),
  ep            = c("PFS", "PFS", "ORR", "PRO"),
  suffix        = c("BM+", "all", "all", "all"), # E.g., for subgroups
  # Type of hypothesis (primary or secondary)
  type          = c("primary", "primary", "secondary", "secondary"),
  # initial weights in graphical multiple testing procedure
  w             = c(1, 0, 0, 0),
  # Spending functions; use NULL if no group sequential test for Hi
  grSeqTesting  = list(
    H1 = list(sfu = gsDesign::sfPower, sfupar = 2),
    H2 = list(sfu = sfPower, sfupar = 2, nominal = 0.0001), 
    H3 = NULL,
    H4 = NULL
  ),
  # 'iaSpec' and 'hypN' are uses to derive the information fractions, 'infoFr',
  # and timing,'iaTiming' (calendar time since study start), for the analyses
  # For each hypothesis, set criteria that trigger analyses through
  # list(A1_list, A2_list, ..., Aj_list), where
  # Aj_list = list(H = 1, atIF = 0.5) means that for that hypothesis analysis
  # j takes place when H1 is at 0.5 information fraction
  iaSpec        = list(
    list(A1 = list(H = 2, atIF = 0.70), A2 = list(H = 2, atIF = 1)),
    list(A1 = list(H = 2, atIF = 0.70),
         A2 = list(H = 2, atIF = 0.85),
         A3 = list(H = 2, atIF = 1)),
    list(A1 = list(H = 2, atIF = 1)),
    list(A1 = list(H = 2, atIF = 1))
  ),
  # Set total information, N, for a given hypothesis (sample size or events);
  # leave NA if 'enrollment' and 'iaSpec' would define N
  hypN          = c(NA, 350, NA, NA),
  # In some cases, would need to define 'infoFr' and 'iaTime' explicitly
  # infoFr        = list(),
  # Calendar time of analysis
  # iaTime        =  list(),
  # To define hypothesis test statistics Zi ~ N(., 1), use 'endpointParam'
  # Class of 'endpointParam' is used to derive effect delta and standardized
  # effect. Standardized effect size is used for power calculations. Several
  # options are available to set test for binary endpoints.
  endpointParam = list(
    structure(
      list(
        p1            = 0.60*log(2)/10,
        p2            = log(2)/10,
        dropoutHazard = -log(1 - 0.05)/12
      ),
      class = "tte_exp"
    ),
    structure(
      list(
        p1            = 0.70*log(2)/15,
        p2            = log(2)/15,
        dropoutHazard = -log(1 - 0.05)/12
      ),
      class = "tte_exp"
    ),
    structure(
      list(
        p1            = 0.85,
        p2            = 0.70,
        maturityTime  = 6
        ),
      class = "binomial_pooled"),
    structure(
      list(
        p1            = 0.45,
        p2            = 0.10,
        maturityTime  = 3
        ),
      class = "normal")
  ),
  # Allocation ratio; trt/control
  allocRatio    = 1,
  # Prevalence of the hypotheses
  prevalence    = c(0.66, 1, 1, 1),
  # Compute enrollment to each hypothesis using its prevalence and the
  # previously set enrollment information
  enrollment    = lapply(prevalence, function(a) {
    purrr::modify_at(enrollmentAll, "rate", ~{a*.x})
  })
)

##### 4. Define graphical testing procedure
graphProc     <- function(s, hypNames = NULL) {
  # s - split parameter
  m             <- matrix(0, numHyp, numHyp)
  m[1, 2]       <-  1
  m[2, 3]       <- 1 - s
  m[2, 4]       <- s
  m[3, 4]       <- 1
  m[4, 3]       <- 1
  if (!is.null(hypNames)) {
    colnames(m) <- rownames(m) <- hypNames
  }
  new("graphMCP", m = m, weights = inputD$w)
}
G             <- graphProc(mtParam,
                           hypNames = paste(inputD$id, inputD$tag, sep = ": "))

##### 5. Depict the graphical testing procedure (refer to ?gMCPLite::hGraph)
graphFigure   <- gMCPLite::hGraph(
  nHypotheses     = numHyp,
  nameHypotheses  = paste(inputD$id, inputD$tag, sep = ": "),
  legend.name     = "Color scheme",
  #labels          = c("Regimen1", "Regimen2"),
  #legend.position = c(.5, 0.2),
  #fill            = rep(1:2, each = numHyp/2),
  #palette         = c("cyan4", "lightblue"),
  halfWid         = 0.4,
  halfHgt         = 0.2,
  trhw            = 0.15,
  trhh            = 0.05,
  offset          = 0.2,
  size            = 4,
  boxtextsize     = 3.5,
  trdigits        = 3,
  # relative position of plots on MT graph
  x               = c(1, 3, 2, 4),
  y               = c(0, 0, -1, -1),
  alphaHypotheses = gMCPLite::getWeights(G),
  m               = gMCPLite::getMatrix(G),
  wchar           = "w"
)

######### << END INPUT >> ######################################################

## ----processInput, include=TRUE, echo=FALSE, message=FALSE----
checkInput(inputD, G)    # check the inputs TODO
main_objects <- exec_calc(inputD)
D            <- main_objects$D
ia_details   <- main_objects$ia_details
hyp_testing  <- main_objects$hyp_testing_dataset

## ----inputTable, include=TRUE, echo=FALSE, results='markup'----
tblInput <- D %>%
    dplyr::select(id, tag, type, w, grSeqTestingCh, deltaStr, hypN) %>%
    dplyr::rename(
        'Label'                    = id,
        'Description'              = tag,
        'Type'                     = type,
        'Initial weight'           = w,
        'Group Sequential Testing' = grSeqTestingCh,
        'Effect size'              = deltaStr,
        'n' = hypN
    )
# adding footnote information
names(tblInput)[6] <-
    paste0(names(tblInput)[6], footnote_marker_symbol (1))
names(tblInput)[7] <-
    paste0(names(tblInput)[7], footnote_marker_symbol (2))

if (is_html_output()) {
    tblInput  %>%
        kable("html", escape = F, align=rep("l",5), caption = "Summary of Primary and Key Secondary Hypotheses") %>%
        kable_styling() %>% 
        footnote(symbol = 
                     c(
                         "Mean difference for binary and continouos endpoints or hazard ratio (HR) for TTE endpoints",
                         "Sample size or number of events for TTE endpoints"
                     )
        )
} else if (is_latex_output()) {
    tblInput %>% 
        mutate_all(linebreak) %>%  
        kable("latex", booktabs = T, escape = F, longtable = TRUE, 
              caption = "Summary of Primary and Key Secondary Hypotheses") %>%
        kable_styling(latex_options = c("hold_position", "repeat_header"))
    #%>% 
    # pack_rows(index = table(fct_inorder(df$hypNames)))
} else if (knitr::pandoc_to("docx")){
    require(flextable)
    df <- data.frame(lapply(tblInput, function(x) {gsub("<br>", "\n", x)}), stringsAsFactors = F)
    flextable(df)
}


## ----MTgraph, fig.cap="Graph Depicting Multiple Hypothesis Testing Strategy.", echo=FALSE, fig.align="center",fig.height=4, fig.width=6----
graphFigure


## ----iaDetailsTableA, include=TRUE, echo=FALSE, results='markup'----
tblAnalysesA <- ia_details                                    %>% 
    dplyr::select(id_tag, ia, criterion, iaTime, n.I, infoFr) %>% 
    dplyr::rename(
        "Hypothesis Analysis"    = ia,
        "Criteria for Conduct"   = criterion,
        "Targeted Analysis Time" = iaTime,
        "n"                      = n.I,
        "Information Fraction"   = infoFr
    )
names(tblAnalysesA)[5] <- paste0(names(tblAnalysesA)[5], footnote_marker_symbol (2))

if (is_html_output()) {
    tblAnalysesA[,-1] %>%
        dplyr::mutate(across(where(is.numeric), ~round(.x,2))) %>%
        kable("html", escape = F, caption = "Summary of Interim Analyses (by hypotheses)") %>%
        kable_styling(position = "center", full_width = FALSE) %>%
        pack_rows( index=table(fct_inorder(tblAnalysesA$id_tag))) %>%
        footnote(symbol = 
                     c(
                         "Sample size or number of evetns for TTE endpoints"
                     )
        )
} else if (is_latex_output()) {
} else if (knitr::pandoc_to("docx")){
    require(flextable)
}

## ----iaDetailsTableB, include=TRUE, echo=FALSE, results='markup'----

tblAnalysesB <- ia_details                                       %>% 
    dplyr::arrange(ia_ind, id_tag)                               %>%
    dplyr::select(ia_ind, id_tag, criterion, iaTime, n.I, infoFr)        %>% 
    dplyr::mutate(
        ia_ind = paste0("Data cut-off #",ia_ind)
        # n_str  = paste0(n.I," (", round(infoFr,idigits)*100, "%)")
    ) %>%
    dplyr::rename(
        "Analysis"               = ia_ind,
        "Hypothesis"             = id_tag, 
        "Criteria for Conduct"   = criterion,
        "Targeted Analysis Time" = iaTime,
        "n"                      = n.I, 
        "Information Fraction"   = infoFr
    )

names(tblAnalysesB)[5] <- paste0(names(tblAnalysesB)[5], footnote_marker_symbol (2))

if (is_html_output()) {
    groupingVec <- tblAnalysesB %>% 
        dplyr::mutate(across(where(is.numeric), ~round(.x,1))) %>%
        dplyr::mutate(
            `Targeted Analysis Time` = paste0("time = ",`Targeted Analysis Time`),
            `Criteria for Conduct`   = paste0("Criteria: ",`Criteria for Conduct`)
        ) %>%
        dplyr::select(`Analysis`,`Targeted Analysis Time`, `Criteria for Conduct`) %>% 
        tidyr::unite(col = calAnalysis, sep=", ")
    
    tblAnalysesB[,c(2,5,6)] %>%
        kable("html", escape = F, caption = "Summary of Interim Analyses (by calendar analysis)",align = c('lrr')) %>%
        kable_styling(position = "center", full_width = FALSE) %>%
        pack_rows( index = table(groupingVec))%>%
        footnote(symbol = 
                     c(
                         "Sample size or number of evetns for TTE endpoints"
                     )
        )
} else if (is_latex_output()) {
} else if (knitr::pandoc_to("docx")){
    require(flextable)
}


## ----timelinePlot, fig.cap="Timelines.", echo=FALSE, fig.align="center",fig.height=6, fig.width=9----
dataAvailPlot <- plot_iaTiming( D %>% distinct(endpointParam, .keep_all = TRUE), 
                                enrollment = enrollmentAll, Tmax=Tmax_atPlot, plotInPercent = plotInPercent)
plot(dataAvailPlot)

## ----graphTable, include=TRUE, echo=FALSE, results='markup'----

knit_MT_table(hyp_testing, digits=5)

## ----grSeqTable, include=TRUE, echo=FALSE, results='markup'----
knit_MT_grSeq_table(hyp_testing, digits=5)

## ----plotSF, eval=TRUE, fig.cap="Alpha-spending functions", echo=FALSE, fig.height=11, fig.width=10----

unSF <- unique( dplyr::select(hyp_testing, hypNames, alpha,timing,spend, sfInfo)) %>% drop_na(spend) 
sfDat <- pmap_dfr(unSF, function(hypNames, alpha, timing, spend, sfInfo) {
  data.frame(
        Hypothesis        = hypNames,
        alpha             = alpha,
        t                 = timing,
        spend             = spend,
        Spending_function = sfInfo,
        alpha_level       = factor(round(alpha, 5))
    )    
})

ggplot(sfDat,
       aes(
         x        = t,
         y        = spend,
         linetype = Spending_function,
         colour   = alpha_level
       )) +
  facet_wrap( ~ Hypothesis, ncol = 1) +
  geom_line() +
  geom_point() +
  labs(x = "Informatin fraction", y = "Cumulative alpha") +
  theme(
    plot.title       = element_text(hjust = 0),
    legend.position  = "bottom",
    legend.direction = "vertical",
    legend.text      = element_text (size = 12),
    legend.title     = element_text(size = 12),
    axis.text        = element_text(size = 12),
    axis.text.x      = element_text(hjust = 1),
    # angle          =45
    axis.title       = element_text(size = 14),
    strip.text.x     = element_text(size = 12)
  )

